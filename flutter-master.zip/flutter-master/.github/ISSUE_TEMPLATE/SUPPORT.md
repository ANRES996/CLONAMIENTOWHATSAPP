---
name: I want help writing my application
about: You have a question for how to achieve a particular effect, or you need help
  with using a particular API.
title: ''
labels: 'created via support template'
assignees: ''

---

<!-- Thank you for using Flutter!

     Please check out our documentation first:
      * https://flutter.dev/
      * https://api.flutter.dev/

     If you can't find the answer there, please consider asking a question on
     the Stack Overflow Web site:
      * https://stackoverflow.com/questions/tagged/flutter?sort=frequent

     Please don't file a GitHub issue for support requests. GitHub issues are
     for tracking defects in the product. If you file a bug asking for help, we
     will consider this a request for a documentation update.

-->
