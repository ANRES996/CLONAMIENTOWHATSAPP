This directory includes scripts and tools for continuous integration builds and tests.
