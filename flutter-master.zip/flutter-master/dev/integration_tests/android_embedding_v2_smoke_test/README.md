# App using Android Embedding 2

A new Flutter project using the Android embedding 2.

This smoke test uses the following plugins:

|        Plugin      | Android Embedding |
|--------------------|-------------------|
|  battery: 0.3.0+5  | 1                 |
