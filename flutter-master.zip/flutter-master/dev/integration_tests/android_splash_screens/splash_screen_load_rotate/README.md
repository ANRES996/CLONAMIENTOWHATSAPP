# Splash Demo: Never ending splash animation

This project is an example of a splash screen that displays an animation indefinitely.

A never ending animation is provided as a demo so that developers can manually verify that 
orientation changes and other UI destruction processes do not cause issues with Flutter's splash 
system for Android. 
