# release_smoke_test

A simple Flutter project used in CI to test that a release app can build and
run on a physical device.
