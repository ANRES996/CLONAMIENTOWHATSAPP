# flavors

Integration test of build flavors (Android product flavors, Xcode schemes).
