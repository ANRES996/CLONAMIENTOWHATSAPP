import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
}
