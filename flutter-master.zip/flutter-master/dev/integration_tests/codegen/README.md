# codegen

A Flutter project for testing code generation.
