# platform_interaction

Integration test of platform interaction.
